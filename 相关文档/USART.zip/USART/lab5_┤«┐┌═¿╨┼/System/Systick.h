#ifndef __SYSTICK_H
#define __SYSTICK_H

void SysTick_Init(uint32_t us);

#endif
