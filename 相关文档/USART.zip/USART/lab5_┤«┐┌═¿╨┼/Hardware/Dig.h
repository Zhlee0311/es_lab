#ifndef __DIG_H
#define __DIG_H

void Dig_Set(void);
void Dig_Init(void);
void Dig_Config(uint16_t Nums);


#endif
