/** Automatically generated file. DO NOT MODIFY */
package com.prolific.pl2300G_multisimpletest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}